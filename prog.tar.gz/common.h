#ifndef _COMMON_H
#define _COMMON_H

typedef int Chess;
#define BLACK 1
#define WHITE -1
#define NUL 0

#define BSIZE 8
void reverse(Chess src[][BSIZE],Chess dest[][BSIZE],int x, int y,Chess thischess);
#endif

